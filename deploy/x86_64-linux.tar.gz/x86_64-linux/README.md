# Free Pascal Editor
Das Programm verwendet gängige Syntaxhervorhebung und ist für MacOS compiliert und getestet. Wer kleine Programme weder mit XCode noch mit Lazarus bearbeiten will, teste dieses Werkzeug. Wer Oberflächen wie für DOS, Windows oder Linux üblich bevorzugt, findet in der MacOS-Version eine Annäherung.

Wer die Anwendung auf einem anderen System testen will, sollte das Quelltextprojekt dafür compilieren können, solange keine fertige unmittelbar ausführbare Version dafür vorliegt. Unmittelbar ausführbare Versionen befinden sich, soweit vorhanden, im Ordner deploy. Übersetzungen in andere Sprachen als Deutsch sind mit Lazarus leicht möglich und werden vielleicht folgen.
